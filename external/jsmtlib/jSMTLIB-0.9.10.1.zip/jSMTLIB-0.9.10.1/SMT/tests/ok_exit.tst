; Valid exit command
(exit)
